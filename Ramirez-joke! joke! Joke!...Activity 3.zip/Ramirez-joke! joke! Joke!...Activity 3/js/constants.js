// API endpoints
var JOKES_API = 'https://geek-jokes.sameerkumar.website/api';
var YN_API = 'https://yesno.wtf/api/';